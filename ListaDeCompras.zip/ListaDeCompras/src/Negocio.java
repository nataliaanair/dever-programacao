import javax.swing.*;
import java.util.ArrayList;

public class Negocio {

    private static final ArrayList<Modelagem> listaDeCompras = new ArrayList<>();

    public static void verListaDePordutos() {
        String lista = "Lista de Compras:\n";
        for (Modelagem model : listaDeCompras) {
            lista += model.getNomeDoItem() + "\n" + model.getPrecoUnitario() + "\n" + "Preço: " + model.getPrecoUnitario();
        }
        JOptionPane.showMessageDialog(null, lista);
    }

    public static void inserirNovoProduto() {

        Modelagem modelagem = new Modelagem();

        String nomeItem = JOptionPane.showInputDialog("Digite o nome do item");
        modelagem.setNomeDoItem(nomeItem);

        String preco = JOptionPane.showInputDialog("Digite o preco do item");
        modelagem.setPrecoUnitario(Integer.parseInt(preco));

        if (modelagem.getNomeDoItem() != null && !modelagem.getNomeDoItem().isEmpty()) {
            listaDeCompras.add(modelagem);
            JOptionPane.showMessageDialog(null, "Novo produto adicionado com sucesso!");
        } else {
            JOptionPane.showMessageDialog(null, "Nome do produto inválido. Tente novamente.");
        }
    }

    public static ArrayList<Modelagem> getListaTelefones() {
        return listaDeCompras;
    }

}
