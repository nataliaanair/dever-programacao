import javax.swing.*;

public class Visao {

    public static void main(String[] args) {

        while (true) {
            String opcao = JOptionPane.showInputDialog("Selecione uma opção:\n1 - Ver lista de compras\n2 - Inserir novo produto\n3 - Sair");

            if (opcao == null || opcao.equals("3")) {
                JOptionPane.showMessageDialog(null, "Saindo do programa.");
                break;
            }

            switch (opcao) {
                case "1":
                    Negocio.verListaDePordutos();
                    break;
                case "2":
                    Negocio.inserirNovoProduto();
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opção inválida. Tente novamente.");
            }
        }
    }


}
