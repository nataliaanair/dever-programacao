import javax.swing.*;

public class Modelagem {

    String nomeDoItem;
    double precoUnitario;

    public String getNomeDoItem() {
        return nomeDoItem;
    }

    public Modelagem setNomeDoItem(String nomeDoItem) {
        this.nomeDoItem = nomeDoItem;
        return this;
    }


    public double getPrecoUnitario() {
        return precoUnitario;
    }

    public Modelagem setPrecoUnitario(double precoUnitario) {
        this.precoUnitario = precoUnitario;
        return this;
    }
}
